# ニーモニックの詩

GitHub の README 参照
https://github.com/avcdsld/code-as-art/tree/main/crypto-modern-poetry
